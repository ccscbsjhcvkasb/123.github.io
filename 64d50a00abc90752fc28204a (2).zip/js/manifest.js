(function () {  

_mrmcp = (typeof _mrmcp == 'undefined') ? {} : _mrmcp;
_mrmcp['campaign_id'] = 'none';
_mrmcp['owner_id'] = '64c4f654eb75b327721f9164';
_mrmcp['creative_id'] = '64d50a00abc90752fc28204a';
_mrmcp['ga_url'] = _mrmcp['ga_url'] || (('https:' == document.location.protocol ? 'https://' : 'http://') + 'card.mugeda.com/weixin/card/ga.js');
_mrmcp['width'] = _mrmcp['width'] || 320;
_mrmcp['height'] = _mrmcp['height'] || 626;
_mrmcp['type'] = 'smart';
_mrmcp['title'] = '别踩白块60帧1';
_mrmcp['build_number'] = parseInt('1192');
_mrmcp['publish_time'] = 'Wed Aug 16 2023 07:27:51 GMT+0800 (China Standard Time)';
_mrmcp['track_bot'] = 'http://cdn.mugeda.com/media/pages/track/track_20131030.html';
_mrmcp['data_server'] = "https://weika.mugeda.com";
})();
